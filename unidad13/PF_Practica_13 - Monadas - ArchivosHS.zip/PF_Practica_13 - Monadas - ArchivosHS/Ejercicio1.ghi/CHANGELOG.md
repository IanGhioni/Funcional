# Revision history for Ejercicio1

## 0.1.0.0 -- YYYY-mm-dd

* First version. Released on an unsuspecting world.

* Monad definitions now include Control.Monad.Fail, and implement instances of Functor, Applicative, and MonadFail
* Those monads are: ErrorMonad, OutputMonad, PowerOutputMonad, and RevOutputMonad