import Monadas  -- Las definiciones de clases necesarias
                --  (mayor que la parte1)
import RNExp    -- El modelo de ejemplo (con la función a COMPLETAR)

main = do putStr "El resultado de (x+1) cuando x es 16 es: "
          print ej1
          putStr "El resultado de (x+1) cuando x es 41 es: "
          print ej2
              
